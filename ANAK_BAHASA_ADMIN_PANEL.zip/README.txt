ANAK BAHASA — Website LABIIB AL GHOFFUUR

Isi:
- index.html
- assets/profile.jpg

Cara pakai:
1. Ekstrak ZIP.
2. Upload index.html dan folder assets ke hosting.
3. Pastikan struktur folder tetap:
   index.html
   assets/profile.jpg

Website menggunakan tautan eksternal untuk toko e-book, WhatsApp, email, dan media sosial.

Catatan:
- Daftar e-book dan harga diambil dari halaman toko Lynk yang diberikan saat website dibuat.
- Domain belum dipasang. Website ini siap dipasang ke hosting/domain apa pun yang mendukung file HTML statis.
