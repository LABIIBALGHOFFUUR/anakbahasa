ADMIN PANEL ANAK BAHASA

Panel admin memakai Decap CMS. Agar tombol Publish benar-benar mengubah website, project harus terhubung ke repository GitHub/GitLab dan Netlify.

Setelah terhubung:
1. Aktifkan Netlify Identity.
2. Aktifkan Git Gateway.
3. Buka /admin/
4. Login.
5. Edit Beranda, Profil, Keahlian, E-book, atau Kontak.
6. Klik Publish.

Referensi:
https://decapcms.org/docs/basic-steps/
https://docs.netlify.com/manage/security/secure-access-to-sites/identity/get-started/
